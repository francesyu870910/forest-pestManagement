# 森林病虫害防治系统 - 模拟数据方案

## 概述

本模拟数据方案为森林病虫害防治系统提供完整的演示数据，包括用户、病虫害、药剂、防治方案、森林资源和知识库等各类数据。系统采用Java对象模拟数据方案，支持数据的自动生成、关联管理、验证和导出功能。

## 系统架构

### 核心组件

1. **数据存储层 (Storage Layer)**
   - `DataStorage`: 主数据存储管理器
   - `UserStorage`: 用户数据存储
   - `PestStorage`: 病虫害数据存储
   - `PesticideStorage`: 药剂数据存储
   - `TreatmentStorage`: 防治方案和任务存储
   - `ForestResourceStorage`: 森林资源数据存储
   - `KnowledgeStorage`: 知识库数据存储
   - `EvaluationStorage`: 效果评估数据存储
   - `PredictionStorage`: 预测预警数据存储

2. **数据工厂层 (Factory Layer)**
   - `DataFactory`: 主数据工厂，协调各个数据生成器
   - `UserDataFactory`: 用户数据生成器
   - `PestDataFactory`: 病虫害数据生成器
   - `PesticideDataFactory`: 药剂数据生成器
   - `TreatmentDataFactory`: 防治方案数据生成器
   - `ForestResourceDataFactory`: 森林资源数据生成器
   - `KnowledgeDataFactory`: 知识库数据生成器

3. **管理层 (Management Layer)**
   - `DataRelationshipManager`: 数据关联关系管理器
   - `DataInitializationService`: 数据初始化服务
   - `DataManagementController`: 数据管理API控制器

4. **工具层 (Utility Layer)**
   - `DataExportUtil`: 数据导出工具
   - `MockDataConfig`: 模拟数据配置管理

## 数据模型

### 用户数据 (Users)
- **管理员用户**: 2个，用户名为admin1、admin2
- **普通用户**: 8个，用户名为user1-user8
- **部门分布**: 森林保护科、病虫害防治科、森林资源管理科等
- **关联关系**: 用户ID关联到防治方案、任务等

### 病虫害数据 (Pests)
- **数量**: 15种常见森林病虫害
- **分类**: 食叶害虫、蛀干害虫、刺吸害虫、真菌病害、细菌病害、病毒病害
- **风险等级**: 低风险、中风险、高风险、极高风险
- **详细信息**: 包含症状、危害特征、发生规律、适宜环境等

### 药剂数据 (Pesticides)
- **数量**: 20种常用药剂
- **分类**: 杀虫剂、杀菌剂、除草剂、生物农药、植物生长调节剂
- **库存管理**: 包含库存数量、有效期、最低库存水平
- **安全信息**: 安全等级、毒性等级、存储条件、使用说明

### 防治方案数据 (Treatment Plans)
- **数量**: 12个防治方案
- **关联**: 每个方案关联特定病虫害和所需药剂
- **方法**: 包含物理防治、生物防治、化学防治等方法
- **状态管理**: 草稿、待审批、已批准、执行中、已完成

### 防治任务数据 (Treatment Tasks)
- **生成规则**: 每个方案生成1-3个任务
- **分配**: 任务分配给普通用户执行
- **时间管理**: 计划时间、实际开始时间、实际结束时间
- **执行记录**: 包含执行备注、使用药剂、照片等

### 森林资源数据 (Forest Resources)
- **层级结构**: 林场 -> 林区 -> 小班
- **数量**: 3个林场，每个林场4个林区，每个林区6个小班
- **属性**: 面积、树种、健康状况、管理水平等
- **地理信息**: 坐标、海拔、坡度、坡向等

### 知识库数据 (Knowledge Base)
- **数量**: 25个知识条目
- **分类**: 病虫害识别、防治技术、药剂使用、设备操作、安全防护、法规标准
- **内容**: 包含详细的技术文档、操作指南、案例分析
- **关联**: 与相关病虫害和防治方法建立关联

## 配置管理

### 配置文件
模拟数据的生成参数可通过 `mock-data-config.yml` 文件进行配置：

```yaml
mock-data:
  users:
    admin-count: 2
    user-count: 8
  pests:
    count: 15
  pesticides:
    count: 20
  # ... 其他配置
```

### 配置类
`MockDataConfig` 类提供了配置参数的Java对象映射，支持运行时动态调整。

## 数据关联关系

### 主要关联关系
1. **用户关联**
   - 防治方案的创建者和审批者
   - 防治任务的分配者和监督者
   - 知识库的作者和审核者

2. **病虫害关联**
   - 防治方案针对特定病虫害
   - 知识库条目关联相关病虫害
   - 效果评估关联病虫害和防治效果

3. **药剂关联**
   - 防治方案指定所需药剂
   - 防治任务记录实际使用药剂
   - 库存管理跟踪药剂使用情况

4. **森林资源关联**
   - 防治方案指定目标区域
   - 层级关系：林场包含林区，林区包含小班

### 关联验证
`DataRelationshipManager` 提供完整的关联关系验证功能：
- 检查外键引用的有效性
- 验证数据的逻辑一致性
- 自动修复无效的关联关系

## API接口

### 数据管理接口
- `POST /api/data-management/initialize` - 初始化演示数据
- `POST /api/data-management/reset` - 重置所有数据
- `POST /api/data-management/regenerate` - 重新生成所有数据
- `GET /api/data-management/statistics` - 获取数据统计信息
- `GET /api/data-management/status` - 检查数据初始化状态

### 数据验证接口
- `GET /api/data-management/validate` - 验证数据关联关系
- `POST /api/data-management/fix-relationships` - 修复数据关联关系

### 数据导出接口
- `GET /api/data-management/export/{dataType}` - 导出指定类型数据
- `GET /api/data-management/data-types` - 获取支持的数据类型

## 使用方法

### 1. 自动初始化
系统启动时会自动初始化模拟数据，无需手动操作。

### 2. 手动管理
通过API接口可以手动管理数据：
```bash
# 重新生成数据
curl -X POST http://localhost:8080/api/data-management/regenerate

# 获取数据统计
curl http://localhost:8080/api/data-management/statistics

# 验证数据关联
curl http://localhost:8080/api/data-management/validate
```

### 3. 数据导出
支持导出各类数据为JSON格式：
```bash
# 导出用户数据
curl http://localhost:8080/api/data-management/export/users

# 导出病虫害数据
curl http://localhost:8080/api/data-management/export/pests
```

## 扩展说明

### 添加新的数据类型
1. 创建对应的存储类（继承或参考现有存储类）
2. 创建数据工厂类生成模拟数据
3. 在 `DataStorage` 中添加新的存储实例
4. 在 `DataFactory` 中调用新的数据生成器
5. 更新关联关系验证逻辑

### 自定义数据生成规则
1. 修改对应的数据工厂类
2. 调整 `mock-data-config.yml` 配置文件
3. 更新 `MockDataConfig` 配置类

### 性能优化
- 数据存储使用 `ConcurrentHashMap` 保证线程安全
- 建立索引提高查询性能
- 支持批量操作减少内存占用

## 注意事项

1. **数据一致性**: 系统会自动验证和维护数据间的关联关系
2. **内存使用**: 所有数据存储在内存中，重启后需要重新生成
3. **线程安全**: 存储层使用线程安全的数据结构
4. **配置灵活**: 支持通过配置文件调整数据生成参数
5. **扩展性**: 架构设计支持轻松添加新的数据类型和生成规则

## 技术特点

- **模块化设计**: 各个数据类型独立管理，便于维护和扩展
- **关联管理**: 自动维护数据间的关联关系和逻辑一致性
- **配置驱动**: 通过配置文件控制数据生成规则
- **API友好**: 提供完整的REST API接口
- **数据导出**: 支持多种格式的数据导出功能
- **验证机制**: 内置数据验证和修复功能